package com.cts.project.bean;

public class EventBean {

}
